# Overview 

This is an example Competition to test if GPUs are available or not